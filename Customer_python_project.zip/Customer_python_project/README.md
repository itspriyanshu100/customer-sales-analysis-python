# Customer Purchase Behavior & Discount Strategy Analysis

## Project Overview
This project analyzes large-scale customer purchase data to extract business insights
and design a data-driven discount strategy for the next financial year.

The goal is to help businesses:
- Identify high-performing cities and product categories
- Analyze sales trends by date and time
- Understand category growth and decline
- Design smart discount, bank-offer, and EMI strategies

---

## Dataset
- 15,000+ customer purchase records
- Fields include:
  - Customer details
  - Product category
  - Purchase date
  - Quantity & pricing
  - Payment method
  - Total transaction value

---

## Project Structure
- `load_data.py` → Load CSV data safely
- `clean_data.py` → Data cleaning pipeline
- `fill_missing.py` → Missing value handling
- `duplicates_handler.py` → Duplicate removal
- `sales_report_by_datetime.py` → Day & time-based sales analysis
- `valuable_insights.py` → City & category insights
- `growth_insights_pvt.py` → Growth analysis using pivot tables
- `discounts_strategy.py` → Business discount logic
- `main.py` → Orchestrates the full pipeline

---

## Key Analysis Performed
- City-wise total sales
- Product category performance
- Day-of-week demand patterns
- Category growth (month-over-month)
- High-value product identification
- EMI eligibility logic

---

## Business Insights
- Electronics and Clothing dominate revenue
- Certain categories show declining growth despite high sales
- Discounts are required even for growing categories to sustain demand
- EMI options significantly improve conversion for high-priced products

---

## Discount Strategy
- Base discount for all products
- Additional card-based discount
- Bank-specific offers (HDFC, ICICI, SBI, Axis)
- EMI eligibility for products above ₹2000/₹3000
- Extra discount for declining growth categories

---

## Tools & Technologies
- Python
- Pandas
- Modular programming
- Pivot tables
- Business logic modeling

---

## Outcome
A complete, modular, real-world data analytics project that demonstrates:
- Data cleaning
- Exploratory analysis
- Business reasoning
- Strategy formulation
