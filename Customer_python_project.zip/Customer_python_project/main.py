# main.py - run this from the project root folder (Customer_python_project)

from sales_analyst_project.load_data import load_csv
from sales_analyst_project.clean_data import clean_all as clean_all_data
from sales_analyst_project.sales_report_by_datetime import (day_by_total_sales, top_products_by_day, price_trends)
from sales_analyst_project.valuable_insights import (sales_by_city, sales_by_product_category) 
from sales_analyst_project.growth_insights_pvt import (category_growth, city_category_growth)
from sales_analyst_project.discounts_strategy import ( apply_base_discount, apply_card_discount, apply_bank_discount, apply_emi_eligibility )  # Placeholder for future use

def main():
    # 1) Load
    df = load_csv()  # uses default filename in data/
    print(df)

    # 2) Clean
    df = clean_all_data(df)
    print(df)

    # 3) Quick checks after cleaning
    print("Shape:", df.shape)
    print("Missing per column:\n", df.isnull().sum())

    # Example analysis: top product categories by revenue
    if "product_category" in df.columns and "total_amount" in df.columns:
        top_categories = df.groupby("product_category")["total_amount"].sum().sort_values(ascending=False)
        print("\nTop product categories by total_amount:\n", top_categories.head(10))
    
        print("\n--- Total sales by day---")
        print(day_by_total_sales(df))

        print("\n--- Top products by day ---")
        print(top_products_by_day(df).head(20))

        print("\n--- Price trends by day ---")
        print(price_trends(df))

        print("\n--- Sales by Cities ---")
        print(sales_by_city(df))

        print("\n--- Sales by Product Category ---")
        print(sales_by_product_category(df).head(20))

        print("\n--- Category Growth Pivot ---")
        print(category_growth(df))

        print("\n--- City Category Growth Pivot ---")
        print(city_category_growth(df))

        df = apply_base_discount(df, base_discount=0.05)
        df = apply_card_discount(df, card_discount=0.03)
        df = apply_bank_discount(df, bank_discount=0.02)
        df = apply_emi_eligibility(df, min_emi=3000)
        
        print(df[
            [
            "total_amount",
            "base_discount_amt",
            "card_discount_amt",
            "bank_discount_amt",
            "final_price",
            "emi_available"
            ]
            ].head())

if __name__ == "__main__":
    main()
