from .duplicates_handler import drop_duplicates
from .fill_missing import fill_numeric_with_mean, fill_dates_with_nat

def clean_all(df):
    """
    Run full cleaning pipeline:
    1) drop duplicates
    2) convert/fill dates
    3) fill numeric columns (total_amount, price_per_unit) with mean if missing
    Returns cleaned DataFrame.
    """
    df = drop_duplicates(df)
    df = fill_dates_with_nat(df, date_col="purchase_date")
    df = fill_numeric_with_mean(df, ["total_amount", "price_per_unit"])
    # You can add more cleaning steps here
    return df
