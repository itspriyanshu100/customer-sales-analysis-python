import pandas as pd
import numpy as np


def apply_base_discount(df: pd.DataFrame, base_discount: float = 0.05) -> pd.DataFrame:
    """
    Apply base discount (festival/category level).
    """
    df = df.copy()

    df["base_discount_amt"] = df["total_amount"] * base_discount
    df["after_base_price"] = df["total_amount"] - df["base_discount_amt"]

    return df


def apply_card_discount(
    df: pd.DataFrame,
    card_type: str = "credit_card",
    card_discount: float = 0.03
) -> pd.DataFrame:
    """
    Apply card-based discount (Credit/Debit).
    """
    df = df.copy()

    if "payment_method" not in df.columns:
        df["card_discount_amt"] = 0
        df["after_card_price"] = df["after_base_price"]
        return df

    df["card_discount_amt"] = np.where(
        df["payment_method"].str.lower().str.contains("credit"),
        df["after_base_price"] * card_discount,
        0
    )

    df["after_card_price"] = df["after_base_price"] - df["card_discount_amt"]

    return df


def apply_bank_discount(
    df: pd.DataFrame,
    bank_name: str = {"hdfc_bank", "icici_bank", "sbi_bank", "axis_bank"},
    bank_discount: float = 0.02
) -> pd.DataFrame:
    """
    Apply bank-specific offer (HDFC, ICICI, SBI, Axis).
    """
    df = df.copy()

    df["bank_discount_amt"] = np.where(
        df["payment_method"].str.lower().str.contains("credit"),
        df["after_card_price"] * bank_discount,
        0
    )

    df["final_price"] = df["after_card_price"] - df["bank_discount_amt"]

    return df


def apply_emi_eligibility(
    df: pd.DataFrame,
    min_emi: float = 3000
) -> pd.DataFrame:
    """
    Mark EMI eligibility for expensive products.
    """
    df = df.copy()

    df["emi_available"] = df["final_price"] >= min_emi

    return df
