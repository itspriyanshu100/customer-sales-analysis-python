def drop_duplicates(df, inplace=False):
    """
    Remove duplicate rows. Returns a new DataFrame unless inplace True.
    """
    before = df.shape[0]
    df2 = df.drop_duplicates(inplace=inplace)
    if inplace:
        removed = before - df.shape[0]
        print(f"Removed {removed} duplicate rows (inplace). New shape: {df.shape}")
        return df
    else:
        removed = before - df2.shape[0]
        print(f"Removed {removed} duplicate rows. New shape: {df2.shape}")
        return df2
