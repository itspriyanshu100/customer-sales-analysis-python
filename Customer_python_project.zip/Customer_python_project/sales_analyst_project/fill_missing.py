import pandas as pd
import numpy as np

def fill_numeric_with_mean(df, columns):
    """Fill specified numeric columns with their mean."""
    for col in columns:
        if col in df.columns:
            mean_val = df[col].mean()
            df[col] = df[col].fillna(mean_val)
            print(f"Filled missing in '{col}' with mean: {mean_val:.2f}")
    return df

def fill_dates_with_nat(df, date_col="purchase_date"):
    """Convert purchase_date to datetime and keep invalid as NaT."""
    if date_col in df.columns:
        df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
        missing_dates = df[date_col].isna().sum()
        print(f"Converted '{date_col}' to datetime. Missing/invalid: {missing_dates}")
    return df
