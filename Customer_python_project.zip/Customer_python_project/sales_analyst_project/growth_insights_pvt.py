import pandas as pd

def category_growth(df):
    """
    Return a pivot table: index = month (Period M),
    column = product_category, values = total_amount aggregated by sum.
    Also provide city-level pivot if needed.
    """
    df = df.copy()
    df["purchase_date"] = pd.to_datetime(df["purchase_date"], errors = "coerce")
    df["month"] = df["purchase_date"].dt.to_period('M')

    # create pivot table to visualize growth per category per month with citys and total sales

    growth_pvt = pd.pivot_table(
        df,
        values='total_amount', #to analyze total sales
        index=['month'], #month as ("index" = rows) 
        columns=['product_category'], #product category as columns 
        aggfunc='sum', #sum of total sales use in aggregation function
        fill_value=0
    )

    return growth_pvt

def city_category_growth(df):
    """
    Pivot with multiindex: (month, product_category) x city -> sum(total_amount)
    Useful to see category performance per city.
    """
    df = df.copy()
    df["purchase_date"] = pd.to_datetime(df["purchase_date"], errors = "coerce")
    df["month"] = df["purchase_date"].dt.to_period('M')

    # create pivot table to visualize growth per category per month with citys and total sales

    city_growth_pvt = pd.pivot_table(
        df,
        values='total_amount', #to analyze total sales
        index=['city', 'month'], #city and month as ("index" = rows) 
        columns=['product_category'], #product category as columns 
        aggfunc='sum', #sum of total sales use in aggregation function
        fill_value=0
    )

    return city_growth_pvt