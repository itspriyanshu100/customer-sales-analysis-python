import pandas as pd
import os

def load_csv(filename="customer_purchases_large.csv"):
    # absolute path to the project folder
    base_dir = os.path.dirname(os.path.dirname(__file__))

    # path to /data folder
    data_path = os.path.join(base_dir, "data", filename)

    df = pd.read_csv(data_path)
    return df
print(load_csv())