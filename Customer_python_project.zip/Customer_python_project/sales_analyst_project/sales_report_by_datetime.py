import pandas as pd

def day_by_total_sales(df):
    df["purchase_date"] = pd.to_datetime(df["purchase_date"], errors="coerce")
    df["day_of_week"] = df["purchase_date"].dt.day_name()

    return (
        df.groupby("day_of_week")["total_amount"]
        .sum()
        .sort_values(ascending=False)
    )

def top_products_by_day(df):
    df["purchase_date"] = pd.to_datetime(df["purchase_date"], errors="coerce")
    df["day_of_week"] = df["purchase_date"].dt.day_name()

    return (
        df.groupby(["day_of_week", "product_category"])["total_amount"]
        .sum()
        .reset_index()
        .sort_values(["day_of_week", "total_amount"], ascending=[True, False])
    )

def price_trends(df):
    df["purchase_date"] = pd.to_datetime(df["purchase_date"], errors="coerce")
    df["day_of_week"] = df["purchase_date"].dt.day_name()

    return (
        df.groupby("day_of_week")["price_per_unit"]
        .mean()
        .reset_index()
        .sort_values("price_per_unit", ascending=False)
    )
