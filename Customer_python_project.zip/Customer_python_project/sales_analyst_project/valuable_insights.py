import pandas as pd

def sales_by_city(df):
    """
      Analyze total sales by cities as per valuable insights requirement.

    And return a DataFrame with total sales per city. 

    """
    #using groupby to calculate total sales per cities 
    sales_cities =  df.groupby ('city')['total_amount'].sum().sort_values(ascending=False).reset_index()
    sales_cities.rename(columns={'total_amount': 'total_sales'}, inplace=True)
    return sales_cities


def sales_by_product_category(df):
    """
      Analyze total sales by product categories as per valuable insights requirement.

    And return a DataFrame with total sales per product category. 

    """


    category_city_sales = (
        df.groupby(['city', 'product_category'])['total_amount']
        .sum()
        .reset_index()
        .sort_values(['city', 'total_amount'], ascending=[True, False])
    )

    category_city_sales.rename(
        columns={'total_amount': 'total_sales'},
        inplace=True
    )

    return category_city_sales
